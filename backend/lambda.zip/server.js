"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const dotenv_1 = __importDefault(require("dotenv"));
dotenv_1.default.config();
const app_1 = __importDefault(require("./app"));
const database_1 = require("./config/database");
const redis_1 = require("./config/redis");
const thread_service_1 = require("./modules/threads/thread.service");
const thread_repository_1 = require("./modules/threads/thread.repository");
const reddit_service_1 = require("./services/reddit.service");
const PORT = parseInt(process.env.PORT ?? "3001", 10);
async function start() {
    // Verify database connectivity
    try {
        await database_1.pool.query("SELECT 1");
        console.log("[DB] Connected to PostgreSQL");
    }
    catch (err) {
        console.error("[DB] Cannot connect – is PostgreSQL running?", err.message);
        process.exit(1);
    }
    // Connect Redis (non-fatal)
    try {
        await redis_1.redis.connect();
    }
    catch (err) {
        console.warn("[Redis] Unavailable – cache disabled:", err.message);
    }
    // Auto-seed default threads from Reddit (non-fatal, runs in background)
    const threadService = new thread_service_1.ThreadService(new thread_repository_1.ThreadRepository(), new reddit_service_1.RedditService());
    threadService.seedDefaultThreads()
        .then(() => console.log("[seed] Default Reddit threads ready"))
        .catch((err) => console.warn("[seed] Could not seed default threads:", err.message));
    app_1.default.listen(PORT, () => {
        console.log(`[server] Listening on http://localhost:${PORT}`);
    });
}
start();
