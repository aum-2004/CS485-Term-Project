"use strict";
/**
 * CommentService – Business Logic Layer
 *
 * Responsibilities:
 *  1. Retrieve enriched comments from cache (Redis) or stable storage (PostgreSQL).
 *  2. Trigger AI analysis for any comment that has not yet been scored.
 *  3. Populate the Redis cache with a 5-minute TTL to support ≥10 simultaneous users
 *     without hammering PostgreSQL.
 *
 * Private members: _repo, _ai, _cache, _buildCacheKey, _analyseNewComments
 * Public members:  getEnrichedComments
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.CommentService = void 0;
const redis_1 = require("../../config/redis");
const CACHE_TTL_SECONDS = 300; // 5 minutes
class CommentService {
    constructor(repo, ai) {
        this._repo = repo;
        this._ai = ai;
    }
    // Private – builds the Redis cache key for a thread's comment list.
    _buildCacheKey(threadId) {
        return `thread:${threadId}:comments`;
    }
    /**
     * Private – runs AI analysis on any comments that have not yet been scored,
     * then persists the results to PostgreSQL.
     */
    async _analyseNewComments(threadId) {
        const unanalysed = await this._repo.findUnanalysed(threadId);
        if (unanalysed.length === 0)
            return;
        // Send all comments in one Gemini API call to stay within rate limits
        const analyses = await this._ai.analyseComments(unanalysed.map((c) => c.content));
        for (let i = 0; i < unanalysed.length; i++) {
            await this._repo.saveAnalysis(unanalysed[i].id, analyses[i].reasoningScore, analyses[i].summary);
        }
    }
    /**
     * Return enriched comments for a thread.
     *
     * Cache-aside pattern:
     *   1. Try Redis – return immediately if present (only cached when fully analysed).
     *   2. Fetch from PostgreSQL (instant).
     *   3. Fire AI analysis in the background for any un-scored comments.
     *   4. Populate Redis cache only when all comments are analysed.
     *
     * Externally visible.
     */
    async getEnrichedComments(threadId) {
        const cacheKey = this._buildCacheKey(threadId);
        // 1. Cache hit (only ever populated when fully analysed)
        try {
            const cached = await redis_1.redis.get(cacheKey);
            if (cached) {
                return JSON.parse(cached);
            }
        }
        catch {
            // Redis unavailable – degrade gracefully
        }
        // 2. Fetch from DB immediately (some may have null scores – that's fine)
        const comments = await this._repo.findByThreadId(threadId);
        // 3. Fire background analysis for any un-scored comments (non-blocking)
        const hasUnanalysed = comments.some((c) => !c.analyzedAt);
        if (hasUnanalysed) {
            void this._analyseNewComments(threadId).catch((err) => {
                console.warn("[CommentService] Background AI analysis failed:", err.message.substring(0, 150));
            });
        }
        else {
            // 4. All analysed – safe to cache
            try {
                await redis_1.redis.setex(cacheKey, CACHE_TTL_SECONDS, JSON.stringify(comments));
            }
            catch {
                // Non-fatal – proceed without cache
            }
        }
        return comments;
    }
    /** Invalidate the cached comment list for a thread. */
    async invalidateCache(threadId) {
        try {
            await redis_1.redis.del(this._buildCacheKey(threadId));
        }
        catch {
            // Non-fatal
        }
    }
}
exports.CommentService = CommentService;
