"use strict";
/**
 * CommentController – HTTP Layer
 *
 * Externally visible REST API:
 *   GET /api/threads/:threadId/comments
 *     → 200  Comment[]
 *     → 404  { error: "Thread not found" }
 *     → 500  { error: "Internal server error" }
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.getComments = getComments;
const comment_service_1 = require("./comment.service");
const comment_repository_1 = require("./comment.repository");
const ai_service_1 = require("../ai/ai.service");
const repo = new comment_repository_1.CommentRepository();
const ai = new ai_service_1.AIService();
const service = new comment_service_1.CommentService(repo, ai);
async function getComments(req, res, next) {
    try {
        const { threadId } = req.params;
        const exists = await repo.threadExists(threadId);
        if (!exists) {
            res.status(404).json({ error: "Thread not found" });
            return;
        }
        const comments = await service.getEnrichedComments(threadId);
        res.json(comments);
    }
    catch (err) {
        next(err);
    }
}
