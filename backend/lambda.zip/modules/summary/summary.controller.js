"use strict";
/**
 * SummaryController – HTTP Layer
 *
 * Externally visible REST API:
 *   GET  /api/threads/:threadId/summary
 *     → 200  DebateSummary
 *     → 404  { error: "Thread not found" }
 *     → 503  { error: "AI quota temporarily exceeded..." }
 *     → 500  { error: "Internal server error" }
 *
 *   POST /api/threads/:threadId/summary/regenerate
 *     → 200  DebateSummary  (freshly regenerated)
 *     → 404  { error: "Thread not found" }
 *     → 503  { error: "AI quota temporarily exceeded..." }
 *     → 500  { error: "Internal server error" }
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.getSummary = getSummary;
exports.regenerateSummary = regenerateSummary;
const summary_service_1 = require("./summary.service");
const summary_repository_1 = require("./summary.repository");
const comment_repository_1 = require("../comments/comment.repository");
const ai_service_1 = require("../ai/ai.service");
const summaryRepo = new summary_repository_1.SummaryRepository();
const commentRepo = new comment_repository_1.CommentRepository();
const ai = new ai_service_1.AIService();
const service = new summary_service_1.SummaryService(summaryRepo, commentRepo, ai);
async function assertThreadExists(threadId, res) {
    const exists = await commentRepo.threadExists(threadId);
    if (!exists) {
        res.status(404).json({ error: "Thread not found" });
        return false;
    }
    return true;
}
/** Returns true if the error is an AI quota / rate-limit failure. */
function isQuotaError(err) {
    const msg = err?.message ?? "";
    return msg.includes("429") || msg.toLowerCase().includes("quota");
}
const QUOTA_MESSAGE = "AI quota temporarily exceeded — the summary will be generated automatically once the quota resets. Please try again in a few minutes.";
async function getSummary(req, res, next) {
    try {
        const { threadId } = req.params;
        if (!(await assertThreadExists(threadId, res)))
            return;
        const summary = await service.getSummary(threadId);
        res.json(summary);
    }
    catch (err) {
        if (isQuotaError(err)) {
            res.status(503).json({ error: QUOTA_MESSAGE });
            return;
        }
        next(err);
    }
}
async function regenerateSummary(req, res, next) {
    try {
        const { threadId } = req.params;
        if (!(await assertThreadExists(threadId, res)))
            return;
        const summary = await service.regenerateSummary(threadId);
        res.json(summary);
    }
    catch (err) {
        if (isQuotaError(err)) {
            res.status(503).json({ error: QUOTA_MESSAGE });
            return;
        }
        next(err);
    }
}
