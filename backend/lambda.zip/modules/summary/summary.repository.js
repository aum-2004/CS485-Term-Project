"use strict";
/**
 * SummaryRepository – Data Abstraction Layer
 *
 * Stable storage: PostgreSQL via pg Pool.
 *
 * Abstraction function:
 *   DB row  →  DebateSummary domain object
 *
 * Rep invariant:
 *   Each thread_id maps to at most one row (UNIQUE constraint in schema).
 *   Arrays main_positions, supporting_evidence, areas_of_disagreement are never null.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.SummaryRepository = void 0;
const uuid_1 = require("uuid");
const database_1 = require("../../config/database");
function rowToSummary(row) {
    return {
        id: row.id,
        threadId: row.thread_id,
        mainPositions: row.main_positions,
        supportingEvidence: row.supporting_evidence,
        areasOfDisagreement: row.areas_of_disagreement,
        generatedAt: row.generated_at.toISOString(),
        updatedAt: row.updated_at.toISOString(),
    };
}
class SummaryRepository {
    /** Return the existing summary for a thread, or null if not yet generated. */
    async findByThreadId(threadId) {
        const { rows } = await database_1.pool.query(`SELECT id, thread_id, main_positions, supporting_evidence,
              areas_of_disagreement, generated_at, updated_at
         FROM debate_summaries
        WHERE thread_id = $1`, [threadId]);
        return rows.length > 0 ? rowToSummary(rows[0]) : null;
    }
    /**
     * Upsert a debate summary.
     * Creates the row on first call; updates in-place on regeneration.
     * Externally visible.
     */
    async upsert(threadId, mainPositions, supportingEvidence, areasOfDisagreement) {
        const id = (0, uuid_1.v4)();
        const { rows } = await database_1.pool.query(`INSERT INTO debate_summaries
         (id, thread_id, main_positions, supporting_evidence, areas_of_disagreement,
          generated_at, updated_at)
       VALUES ($1, $2, $3, $4, $5, NOW(), NOW())
       ON CONFLICT (thread_id) DO UPDATE
          SET main_positions        = EXCLUDED.main_positions,
              supporting_evidence   = EXCLUDED.supporting_evidence,
              areas_of_disagreement = EXCLUDED.areas_of_disagreement,
              updated_at            = NOW()
       RETURNING *`, [id, threadId, mainPositions, supportingEvidence, areasOfDisagreement]);
        return rowToSummary(rows[0]);
    }
}
exports.SummaryRepository = SummaryRepository;
