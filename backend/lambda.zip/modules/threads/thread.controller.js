"use strict";
/**
 * ThreadController – HTTP Layer
 *
 * Externally visible REST API:
 *   GET    /api/threads          → 200  Thread[]
 *   POST   /api/threads          body: { redditUrl }  → 201 Thread
 *   POST   /api/threads/custom   body: { title, comments: [{author,content}] } → 201 Thread
 *   DELETE /api/threads/:id      → 204 | 404
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.getThreads = getThreads;
exports.createThread = createThread;
exports.createCustomThread = createCustomThread;
exports.deleteThread = deleteThread;
exports.refreshSeededThreads = refreshSeededThreads;
const thread_service_1 = require("./thread.service");
const thread_repository_1 = require("./thread.repository");
const reddit_service_1 = require("../../services/reddit.service");
const repo = new thread_repository_1.ThreadRepository();
const reddit = new reddit_service_1.RedditService();
const service = new thread_service_1.ThreadService(repo, reddit);
async function getThreads(_req, res, next) {
    try {
        const threads = await service.getAllThreads();
        res.json(threads);
    }
    catch (err) {
        next(err);
    }
}
async function createThread(req, res, next) {
    try {
        const { redditUrl } = req.body;
        if (!redditUrl || typeof redditUrl !== "string" || !redditUrl.trim()) {
            res.status(400).json({ error: "redditUrl is required" });
            return;
        }
        try {
            const thread = await service.addRedditThread(redditUrl.trim());
            res.status(201).json(thread);
        }
        catch (err) {
            const msg = err.message;
            if (msg.startsWith("Invalid Reddit URL") || msg.startsWith("No readable comments")) {
                res.status(400).json({ error: msg });
            }
            else if (msg.startsWith("Failed to reach Reddit API") || msg.startsWith("Reddit API returned")) {
                res.status(502).json({ error: msg });
            }
            else {
                throw err;
            }
        }
    }
    catch (err) {
        next(err);
    }
}
async function createCustomThread(req, res, next) {
    try {
        const { title, comments } = req.body;
        if (!title || typeof title !== "string" || !title.trim()) {
            res.status(400).json({ error: "title is required" });
            return;
        }
        if (!Array.isArray(comments) || comments.length === 0) {
            res.status(400).json({ error: "At least one comment is required" });
            return;
        }
        const thread = await service.createCustomThread(title.trim(), comments);
        res.status(201).json(thread);
    }
    catch (err) {
        next(err);
    }
}
async function deleteThread(req, res, next) {
    try {
        const { threadId } = req.params;
        const deleted = await service.deleteThread(threadId);
        if (!deleted) {
            res.status(404).json({ error: "Thread not found" });
            return;
        }
        res.status(204).send();
    }
    catch (err) {
        next(err);
    }
}
/**
 * POST /api/threads/seed/refresh
 * Wipes stale auto-seeded threads, fetches today's hot posts from Reddit,
 * and returns the full updated thread list.
 * Called by the frontend on every page load so users always see fresh content.
 */
async function refreshSeededThreads(_req, res, next) {
    try {
        await service.seedDefaultThreads();
        const threads = await service.getAllThreads();
        res.json(threads);
    }
    catch (err) {
        next(err);
    }
}
