"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const dotenv_1 = __importDefault(require("dotenv"));
const comment_controller_1 = require("./modules/comments/comment.controller");
const summary_controller_1 = require("./modules/summary/summary.controller");
const thread_controller_1 = require("./modules/threads/thread.controller");
const error_middleware_1 = require("./middleware/error.middleware");
dotenv_1.default.config();
const app = (0, express_1.default)();
app.use((0, cors_1.default)({
    origin: process.env.CORS_ORIGIN ?? "http://localhost:5173",
    methods: ["GET", "POST", "DELETE"],
}));
app.use(express_1.default.json());
// Health check
app.get("/health", (_req, res) => {
    res.json({ status: "ok", timestamp: new Date().toISOString() });
});
// ── Thread management ─────────────────────────────────────────────────────────
app.get("/api/threads", thread_controller_1.getThreads);
app.post("/api/threads/seed/refresh", thread_controller_1.refreshSeededThreads); // called on every page load
app.post("/api/threads", thread_controller_1.createThread);
app.post("/api/threads/custom", thread_controller_1.createCustomThread);
app.delete("/api/threads/:threadId", thread_controller_1.deleteThread);
// ── User Story A: Inline AI Reasoning Summary ────────────────────────────────
app.get("/api/threads/:threadId/comments", comment_controller_1.getComments);
// ── User Story B: Moderator Debate Summary ───────────────────────────────────
app.get("/api/threads/:threadId/summary", summary_controller_1.getSummary);
app.post("/api/threads/:threadId/summary/regenerate", summary_controller_1.regenerateSummary);
app.use(error_middleware_1.errorHandler);
exports.default = app;
