"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const database_1 = require("../config/database");
async function migrate() {
    const schemaPath = path_1.default.join(__dirname, "schema.sql");
    const sql = fs_1.default.readFileSync(schemaPath, "utf8");
    console.log("[migrate] Running schema...");
    await database_1.pool.query(sql);
    console.log("[migrate] Done.");
    await database_1.pool.end();
}
migrate().catch((err) => {
    console.error("[migrate] Error:", err.message);
    process.exit(1);
});
