"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const database_1 = require("../config/database");
/**
 * Seed script – no fake data in production.
 * Real threads are added by users via POST /api/threads with a Reddit URL.
 */
async function seed() {
    console.log("[seed] No seed data to insert. Add threads via the UI.");
    await database_1.pool.end();
}
seed().catch((err) => {
    console.error("[seed] Error:", err.message);
    process.exit(1);
});
