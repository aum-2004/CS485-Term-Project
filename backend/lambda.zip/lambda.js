"use strict";
/**
 * AWS Lambda entry point.
 *
 * Wraps the Express application with @vendia/serverless-express so that
 * API Gateway proxy events are translated into Express req/res cycles.
 *
 * Local development still uses server.ts (npm run dev).
 * Lambda deployment uses this file via the build output: dist/lambda.js
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.lambdaHandler = void 0;
const serverless_express_1 = __importDefault(require("@vendia/serverless-express"));
const app_1 = __importDefault(require("./app"));
// One-time bootstrap: create the adapter at cold-start, reuse across warm invocations.
// Exported directly as lambdaHandler for use in Lambda runtime.
exports.lambdaHandler = (0, serverless_express_1.default)({ app: app_1.default });
