"use strict";
/**
 * RedditService – fetches real thread data from Reddit's public JSON API.
 *
 * No authentication required for public posts.
 * API: https://www.reddit.com/r/{sub}/comments/{id}.json?limit=25&raw_json=1
 *
 * Supported URL formats:
 *   https://www.reddit.com/r/science/comments/abc123/title/
 *   reddit.com/r/science/comments/abc123/
 *   https://www.reddit.com/r/science/comments/abc123
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.RedditService = void 0;
const USER_AGENT = "CS485DebateAnalyzer/1.0";
const MAX_COMMENTS = 25;
class RedditService {
    /**
     * Parse the Reddit post ID from any recognised URL format.
     * Throws if the URL is not a valid Reddit thread URL.
     */
    parsePostId(url) {
        const match = url.match(/reddit\.com\/r\/[^/]+\/comments\/([a-z0-9]+)/i);
        if (!match) {
            throw new Error("Invalid Reddit URL. Expected format: https://www.reddit.com/r/<sub>/comments/<id>/...");
        }
        return match[1];
    }
    /**
     * Fetch a Reddit thread and return its title plus top-level comments.
     * Externally visible.
     */
    async fetchThread(redditUrl) {
        const postId = this.parsePostId(redditUrl);
        const apiUrl = `https://www.reddit.com/comments/${postId}.json?limit=${MAX_COMMENTS}&raw_json=1`;
        let data;
        try {
            const res = await fetch(apiUrl, {
                headers: {
                    "User-Agent": USER_AGENT,
                    Accept: "application/json",
                },
            });
            if (!res.ok) {
                throw new Error(`Reddit API returned HTTP ${res.status}`);
            }
            data = await res.json();
        }
        catch (err) {
            throw new Error(`Failed to reach Reddit API: ${err.message}`);
        }
        return this._parse(postId, data);
    }
    /**
     * Fetch the top N hot post URLs from a subreddit.
     * Returns full reddit.com URLs suitable for passing to fetchThread().
     * Externally visible.
     */
    async fetchSubredditHot(subreddit, limit = 3) {
        return this._fetchSubredditFeed(subreddit, "hot", limit);
    }
    /**
     * Fetch the N most recently submitted post URLs from a subreddit.
     * Updates every minute — use this for fresh content on each page load.
     * Externally visible.
     */
    async fetchSubredditNew(subreddit, limit = 10) {
        return this._fetchSubredditFeed(subreddit, "new", limit);
    }
    /** Shared fetcher for any subreddit feed (hot / new / rising). */
    async _fetchSubredditFeed(subreddit, feed, limit) {
        const apiUrl = `https://www.reddit.com/r/${subreddit}/${feed}.json?limit=${limit}&raw_json=1`;
        try {
            const res = await fetch(apiUrl, {
                headers: { "User-Agent": USER_AGENT, Accept: "application/json" },
            });
            if (!res.ok)
                throw new Error(`HTTP ${res.status}`);
            const data = await res.json();
            return data.data.children
                .filter((c) => !c.data.stickied)
                .map((c) => `https://www.reddit.com/r/${subreddit}/comments/${c.data.id}`)
                .slice(0, limit);
        }
        catch (err) {
            throw new Error(`Failed to fetch r/${subreddit} ${feed}: ${err.message}`);
        }
    }
    /** Parse the raw Reddit API response into our domain shape. */
    _parse(postId, data) {
        const listings = data;
        if (!Array.isArray(listings) || listings.length < 2) {
            throw new Error("Unexpected Reddit API response format");
        }
        const postData = listings[0]?.data?.children?.[0]?.data;
        const title = postData?.title ?? "Reddit Thread";
        const commentChildren = listings[1]?.data?.children ?? [];
        const comments = [];
        for (const child of commentChildren) {
            if (child.kind !== "t1")
                continue;
            const d = child.data;
            // Skip deleted / removed / AutoModerator
            if (!d.body || d.body === "[deleted]" || d.body === "[removed]")
                continue;
            if (!d.author || d.author === "[deleted]" || d.author === "AutoModerator")
                continue;
            comments.push({
                id: `reddit_comment_${d.id}`,
                author: d.author,
                content: d.body.slice(0, 2000), // cap length
            });
            if (comments.length >= MAX_COMMENTS)
                break;
        }
        if (comments.length === 0) {
            throw new Error("No readable comments found in this Reddit thread");
        }
        return {
            threadId: `reddit_${postId}`,
            title,
            comments,
        };
    }
}
exports.RedditService = RedditService;
